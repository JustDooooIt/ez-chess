using Godot;

public class Pieces : Group<Vector2I, IPiece>
{
  
}