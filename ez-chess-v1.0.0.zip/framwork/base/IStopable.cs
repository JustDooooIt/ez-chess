using System.Threading.Tasks;

public interface IStopable
{
  void Stop();
}