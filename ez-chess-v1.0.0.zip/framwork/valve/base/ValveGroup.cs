using System.Collections.Generic;
using System.Threading.Tasks;

public abstract partial class ValveGroup : Pipeline
{

}
