public interface IValve: ILaunchable
{
  
}