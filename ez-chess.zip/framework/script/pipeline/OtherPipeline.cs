using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using Godot;

public partial class OtherPipeline : PlayerPipeline
{
	public override void _Ready()
	{
		base._Ready();
	}

}
