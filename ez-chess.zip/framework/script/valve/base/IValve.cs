public interface IValve: ILaunchable
{
  
}